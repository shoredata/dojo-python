import datetime 
from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)  

app.secret_key = "98yas9asdfadsfadsdf8hasd9fadhsfo"

def initsession():
    if 'apple' not in session:
        session['apple'] = 0
        session['blackberry'] = 0
        session['strawberry'] = 0
        session['raspberry'] = 0

        session['itemcount'] = 0

        session['first_name'] = ""
        session['last_name'] = ""
        session['student_id'] = ""

        session['orderdatetime'] = ""
    return

def clearsession():
    session.clear()
    return


@app.route('/')         
def index():
    print("--ROOT--")
    initsession()
    return render_template("index.html")

@app.route('/begin')         
def clearsess():
    print("--BEGIN--")
    clearsession()
    return redirect("/")


@app.route('/checkout', methods=['POST'])         
def checkout():
    print("PROCESS CHECKOUT ACTION")
    initsession()
    print(request.form)

    session['apple'] = request.form.get('apple')
    session['blackberry'] = request.form.get('blackberry')
    session['strawberry'] = request.form.get('strawberry')
    session['raspberry'] = request.form.get('raspberry')

    session['first_name'] = request.form.get('first_name')
    session['last_name'] = request.form.get('last_name')
    session['student_id'] = request.form.get('student_id')

    session['orderdatetime'] = datetime.datetime.now()
    session['itemcount'] = int(session['apple']) + int(session['raspberry']) + int(session['blackberry']) + int(session['strawberry'])

    return redirect("/success")


@app.route('/success')         
def success():
    print("--CHECKOUT COMPLETE--")
    return render_template("checkout.html")


@app.route('/fruits')         
def fruits():
    print("--FRUITS--")
    return render_template("fruits.html")


if __name__=="__main__":   
    app.run(debug=True)    












# output:

# 17:41:12 bart ~/projects/cd/python/flfun/dojo_fruit_store (master)
# $ python server.py
#  * Serving Flask app "server" (lazy loading)
#  * Environment: production
#    WARNING: Do not use the development server in a production environment.
#    Use a production WSGI server instead.
#  * Debug mode: on
#  * Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)
#  * Restarting with stat
#  * Debugger is active!
#  * Debugger PIN: 151-374-095
# --ROOT--
# 127.0.0.1 - - [08/Jun/2018 17:41:20] "GET / HTTP/1.1" 200 -
# --FRUITS--
# 127.0.0.1 - - [08/Jun/2018 17:41:22] "GET /fruits HTTP/1.1" 200 -
# --ROOT--
# 127.0.0.1 - - [08/Jun/2018 17:41:23] "GET / HTTP/1.1" 200 -
# --BEGIN--
# 127.0.0.1 - - [08/Jun/2018 17:41:25] "GET /begin HTTP/1.1" 302 -
# --ROOT--
# 127.0.0.1 - - [08/Jun/2018 17:41:25] "GET / HTTP/1.1" 200 -
# PROCESS CHECKOUT ACTION
# ImmutableMultiDict([('blackberry', '4'), ('strawberry', '4'), ('raspberry', '4'), ('apple', '4'), ('first_name', 'Barton'), ('last_name', 'Schaefer'), ('student_id', '123-456-7891')])
# 127.0.0.1 - - [08/Jun/2018 17:41:38] "POST /checkout HTTP/1.1" 302 -
# --CHECKOUT COMPLETE--
# 127.0.0.1 - - [08/Jun/2018 17:41:38] "GET /success HTTP/1.1" 200 -
# --ROOT--
# 127.0.0.1 - - [08/Jun/2018 17:41:40] "GET / HTTP/1.1" 200 -
